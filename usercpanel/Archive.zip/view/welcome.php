<?php

echo time();

echo "microtime is \n".microtime(true);

?>
<style>
.head {
	font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, AppleGothic, sans-serif;
	font-size: 74px;
	
	font-weight: normal;
	align-self: center;
	display: flex;
	color: #e2e2e2;
	margin-bottom: 0px;
	margin-top: 0px;
}

.sub-head {
	font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, AppleGothic, sans-serif;
	font-size: 24px;
	
	font-weight: normal;
	display: flex;
	text-align: center;
	color: #e2e2e2;
	margin-bottom: 0px;
	padding-left: 26px;
	padding-bottom: 12px;
}


div {
    

    position: fixed;
    top: 32%;
    left: 35%;
    
}
</style>
<div>
<p class="sub-head">Welcome !</p>

<p class="head">Corlov  1.0</p>
</div>