<?php
session_destroy();

echo "<script>window.open('login','_self')</script>";

?>